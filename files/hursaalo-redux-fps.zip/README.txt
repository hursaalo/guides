hursaalo GTA 5 redux — FPS — только резкость и цвет, минимум просадки

Установка:
1. Поставь ReShade с reshade.me (официальный сайт) на GTA5.exe (FiveM: FiveM_GTAProcess.exe),
   пакеты эффектов: Standard effects + SweetFX.
2. Положи hursaalo-redux-fps.ini в папку игры (рядом с GTA5.exe).
3. В игре: Home -> вверху выбери пресет hursaalo-redux-fps.ini.
4. Scroll Lock — включить/выключить, чтобы сравнить.

Это только цветокоррекция: деревья/траву/туман не убирает, на RP-серверах разрешено,
если в правилах не запрещён ReShade.
Полный гайд: https://hursaalo.github.io/guides/gta5-graphics.html
